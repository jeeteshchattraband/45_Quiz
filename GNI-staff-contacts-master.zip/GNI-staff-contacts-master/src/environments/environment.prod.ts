export const environment = {
  production: true,
  appApi: {
    baseUrl: 'http://api.example.com'
  },
  socketConfig: {
    url: 'http://dev.contacts.com:3000'
  }
};
