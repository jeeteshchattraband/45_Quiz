export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyAdF8NVYvqpuesvxil7id4phi8y931p5uI",
    authDomain: "angular-portfolio-fd68f.firebaseapp.com",
    databaseURL: "https://angular-portfolio-fd68f.firebaseio.com",
    projectId: "angular-portfolio-fd68f",
    storageBucket: "angular-portfolio-fd68f.appspot.com",
    messagingSenderId: "446735974078"
  }
};
