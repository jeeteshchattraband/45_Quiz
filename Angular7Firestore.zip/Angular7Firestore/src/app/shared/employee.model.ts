export class Employee {
    id: string;
    fullName: string;
    PinCode: string;
    position: string;
    mobile: string;
}